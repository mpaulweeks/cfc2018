// this snippet of javascript will execute code from comments.js
// it will setup your form to submit correctly, and load previously submitted comments
// make sure you have a form with id="comments-form" and a div with id="comments-view"

// replace "example" with your name eg "paul"
CFC.Comments.Setup("example");
